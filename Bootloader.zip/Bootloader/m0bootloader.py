import os
openocd_cmd = "openocd"
programbootstr = " -d2 -s scripts/ -f arduino_zero.cfg -c \"telnet_port disabled; init; halt; at91samd bootloader 0; program {{Bootloader_D21_M0_150515.hex}} verify reset; shutdown\""
print([openocd_cmd,programbootstr])
if os.name == 'posix':
    import subprocess
    process = subprocess.Popen('./'+openocd_cmd+programbootstr,stdout=subprocess.PIPE, shell=True)
    result = process.communicate()[0].strip()
elif os.name == 'nt':
    from subprocess import check_output
    result = check_output(openocd_cmd+programbootstr,shell=True)

print(result)


